const path=require('node:path');
const fs=require('node:fs');
const express=require('express');
const session=require('express-session');
const SQLiteStore=require('connect-sqlite3')(session);
const bcrypt=require('bcryptjs');
const helmet=require('helmet');
const rateLimit=require('express-rate-limit');
const {z}=require('zod');
const {lessons,counts}=require('./data/catalog');

const app=express();
const port=Number(process.env.PORT||3000);
const dataDir=path.resolve(process.env.DATABASE_PATH?path.dirname(process.env.DATABASE_PATH):path.join(__dirname,'../data'));
if(!process.env.SESSION_SECRET || process.env.SESSION_SECRET.length<32) {
  if(process.env.NODE_ENV==='production') throw new Error('SESSION_SECRET must be set to a random value of at least 32 characters');
  process.env.SESSION_SECRET='dev-only-change-this-session-secret-before-deploy-123456789';
}
app.disable('x-powered-by');
app.use(helmet({contentSecurityPolicy:false}));
app.use(express.json({limit:'32kb'}));
const usePostgres=Boolean(process.env.DATABASE_URL);
let db,pgPool,dbReady=Promise.resolve();
if(usePostgres){
  const {Pool}=require('pg');
  pgPool=new Pool({connectionString:process.env.DATABASE_URL,max:5,idleTimeoutMillis:30000,connectionTimeoutMillis:10000});
  if(process.env.VERCEL){try{require('@vercel/functions').attachDatabasePool(pgPool)}catch{}}
  const PgStore=require('connect-pg-simple')(session);
  app.use(session({store:new PgStore({pool:pgPool,createTableIfMissing:true}),secret:process.env.SESSION_SECRET,resave:false,saveUninitialized:false,cookie:{httpOnly:true,sameSite:'lax',secure:true,maxAge:1000*60*60*12}}));
  dbReady=(async()=>{
    await pgPool.query(`CREATE TABLE IF NOT EXISTS users(id BIGSERIAL PRIMARY KEY,name TEXT NOT NULL,email TEXT NOT NULL UNIQUE,password_hash TEXT NOT NULL,role TEXT NOT NULL DEFAULT 'student',created_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP)`);
    await pgPool.query(`CREATE TABLE IF NOT EXISTS progress(user_id BIGINT NOT NULL REFERENCES users(id),lesson_id TEXT NOT NULL,score INTEGER NOT NULL,completed_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,PRIMARY KEY(user_id,lesson_id))`);
  })();
}else{
  fs.mkdirSync(dataDir,{recursive:true});
  const sqlite3=require('sqlite3').verbose();
  db=new sqlite3.Database(path.resolve(process.env.DATABASE_PATH||path.join(__dirname,'../data/lingua.db')));
  db.serialize(()=>{
    db.run('PRAGMA journal_mode=WAL');
    db.run(`CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT NOT NULL,email TEXT NOT NULL UNIQUE,password_hash TEXT NOT NULL,role TEXT NOT NULL DEFAULT 'student',created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)`);
    db.run(`CREATE TABLE IF NOT EXISTS progress(user_id INTEGER NOT NULL,lesson_id TEXT NOT NULL,score INTEGER NOT NULL,completed_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,PRIMARY KEY(user_id,lesson_id),FOREIGN KEY(user_id) REFERENCES users(id))`);
  });
  app.use(session({store:new SQLiteStore({db:'sessions.sqlite',dir:dataDir}),secret:process.env.SESSION_SECRET,resave:false,saveUninitialized:false,cookie:{httpOnly:true,sameSite:'lax',secure:process.env.NODE_ENV==='production',maxAge:1000*60*60*12}}));
}
const loginLimit=rateLimit({windowMs:15*60*1000,limit:10,standardHeaders:true,legacyHeaders:false});
const asyncRoute=fn=>(req,res,next)=>Promise.resolve(fn(req,res,next)).catch(next);
const requireUser=(req,res,next)=>req.session.user?next():res.status(401).json({error:'يلزم تسجيل الدخول.'});
const requireAdmin=(req,res,next)=>req.session.user?.role==='admin'?next():res.status(req.session.user?403:401).json({error:'لا تملك صلاحية تنفيذ هذا الإجراء.'});
const safeUser=u=>({id:u.id,name:u.name,email:u.email,role:u.role});
const toPgSql=sql=>{let i=0;return sql.replace(/\?/g,()=>`$${++i}`)};
const dbGet=async(sql,args=[])=>{await dbReady;if(usePostgres){const r=await pgPool.query(toPgSql(sql),args);return r.rows[0]}return new Promise((resolve,reject)=>db.get(sql,args,(e,row)=>e?reject(e):resolve(row)))};
const dbAll=async(sql,args=[])=>{await dbReady;if(usePostgres){const r=await pgPool.query(toPgSql(sql),args);return r.rows}return new Promise((resolve,reject)=>db.all(sql,args,(e,row)=>e?reject(e):resolve(row)))};
const dbRun=async(sql,args=[])=>{await dbReady;if(usePostgres){const insertUser=/^\s*INSERT\s+INTO\s+users\b/i.test(sql);const r=await pgPool.query(toPgSql(sql)+(insertUser?' RETURNING id':''),args);return {lastID:r.rows[0]?.id,changes:r.rowCount}}return new Promise((resolve,reject)=>db.run(sql,args,function(e){e?reject(e):resolve(this)}))};

app.get('/api/health',(req,res)=>res.json({ok:true,service:'sama-api'}));
app.get('/api/auth/me',(req,res)=>res.json({user:req.session.user||null}));
app.post('/api/auth/register',loginLimit,asyncRoute(async(req,res)=>{
  const parsed=z.object({name:z.string().trim().min(2).max(80),email:z.string().trim().email().max(160),password:z.string().min(10).max(128)}).safeParse(req.body);
  if(!parsed.success)return res.status(400).json({error:'راجع الاسم والبريد وكلمة المرور (10 أحرف على الأقل).'});
  const {name,email,password}=parsed.data;
  const hash=await bcrypt.hash(password,12);
  try {const insert=await dbRun('INSERT INTO users(name,email,password_hash,role) VALUES(?,?,?,?)',[name,email.toLowerCase(),hash,'student']);
    const user=safeUser({id:insert.lastID,name,email:email.toLowerCase(),role:'student'}); req.session.user=user; res.status(201).json({user});
  } catch(e){if(e.code==='SQLITE_CONSTRAINT'||e.code==='23505')return res.status(409).json({error:'هذا البريد مسجل من قبل.'});throw e;}
}));
app.post('/api/auth/login',loginLimit,asyncRoute(async(req,res)=>{
  const parsed=z.object({email:z.string().email().max(160),password:z.string().min(1).max(128)}).safeParse(req.body);
  if(!parsed.success)return res.status(400).json({error:'أدخل بريدًا وكلمة مرور صالحين.'});
  const user=await dbGet('SELECT id,name,email,password_hash,role FROM users WHERE email=?',[parsed.data.email.toLowerCase()]);
  if(!user || !await bcrypt.compare(parsed.data.password,user.password_hash))return res.status(401).json({error:'البريد أو كلمة المرور غير صحيحة.'});
  req.session.regenerate(err=>{if(err)return res.status(500).json({error:'تعذر بدء الجلسة.'});req.session.user=safeUser(user);res.json({user:req.session.user});});
}));
app.post('/api/auth/logout',requireUser,(req,res)=>req.session.destroy(()=>res.clearCookie('connect.sid',{httpOnly:true,sameSite:'lax',secure:process.env.NODE_ENV==='production'}).json({ok:true})));

app.get('/api/catalog',requireUser,(req,res)=>res.json({counts,lessons:lessons.map(({id,section,level,title,tag,minutes})=>({id,section,level,title,tag,minutes}))}));
app.get('/api/lessons/:id',requireUser,asyncRoute(async(req,res)=>{
  const l=lessons.find(x=>x.id===req.params.id);if(!l)return res.status(404).json({error:'الدرس غير موجود.'});
  const progress=await dbGet('SELECT score,completed_at FROM progress WHERE user_id=? AND lesson_id=?',[req.session.user.id,l.id]);
  const clean={...l,questions:l.questions?.map(({q,choices})=>({q,choices}))};
  if(l.section==='listening')delete clean.transcript;
  if(l.section==='dictation')delete clean.text;
  res.json({lesson:clean,progress:progress||null});
}));
app.get('/api/lessons/:id/audio',requireUser,(req,res)=>{
  const l=lessons.find(x=>x.id===req.params.id);if(!l)return res.status(404).json({error:'الدرس غير موجود.'});
  res.json({text:l.transcript||l.passage||l.text||'',voicePreference:'first-en-US'});
});
app.post('/api/lessons/:id/submit',requireUser,asyncRoute(async(req,res)=>{
  const l=lessons.find(x=>x.id===req.params.id);if(!l)return res.status(404).json({error:'الدرس غير موجود.'});
  let score=0,result;
  if(l.section==='dictation'){
    const parsed=z.object({text:z.string().max(5000)}).safeParse(req.body);if(!parsed.success)return res.status(400).json({error:'النص غير صالح.'});
    const normalize=s=>s.toLowerCase().replace(/[^a-z0-9']/g,' ').trim().split(/\s+/).filter(Boolean);
    const expected=normalize(l.text),actual=normalize(parsed.data.text);let exact=0;
    expected.forEach((w,i)=>{if(actual[i]===w)exact++});score=expected.length?Math.round(exact/expected.length*100):0;
    result={score,correctText:l.text,expectedWords:expected.length,matchedWords:exact,wordFeedback:expected.map((word,i)=>({expected:word,entered:actual[i]||'',correct:actual[i]===word}))};
  }else{
    const parsed=z.object({answers:z.array(z.number().int().min(0).max(8)).length(6)}).safeParse(req.body);if(!parsed.success || !l.questions)return res.status(400).json({error:'الإجابات غير مكتملة.'});
    const feedback=l.questions.map((q,i)=>({correct:parsed.data.answers[i]===q.answer,correctAnswer:q.answer}));score=Math.round(feedback.filter(x=>x.correct).length/feedback.length*100);result={score,correctCount:feedback.filter(x=>x.correct).length,total:feedback.length,feedback};
  }
  await dbRun(`INSERT INTO progress(user_id,lesson_id,score) VALUES(?,?,?) ON CONFLICT(user_id,lesson_id) DO UPDATE SET score=excluded.score,completed_at=CURRENT_TIMESTAMP`,[req.session.user.id,l.id,score]);
  res.json(result);
}));
app.get('/api/progress',requireUser,asyncRoute(async(req,res)=>{
  const rows=await dbAll('SELECT lesson_id AS lessonId,score,completed_at AS completedAt FROM progress WHERE user_id=? ORDER BY completed_at DESC',[req.session.user.id]);
  res.json({items:rows,summary:{completed:rows.length,points:rows.reduce((a,x)=>a+x.score,0)}});
}));
app.get('/api/admin/users',requireUser,requireAdmin,asyncRoute(async(req,res)=>res.json({users:(await dbAll('SELECT id,name,email,role,created_at AS createdAt FROM users ORDER BY id DESC')).map(safeUser)})));
if(process.env.NODE_ENV==='production'){
  const dist=path.resolve(__dirname,'../client/dist');app.use(express.static(dist));app.get('*',(req,res)=>res.sendFile(path.join(dist,'index.html')));
}
app.use((err,req,res,next)=>{console.error(err);res.status(500).json({error:'حدث خطأ داخلي. حاول مرة أخرى.'})});
if(require.main===module)app.listen(port,()=>console.log(`Sama API listening on http://localhost:${port}`));
module.exports=app;
