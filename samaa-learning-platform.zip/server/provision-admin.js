const bcrypt=require('bcryptjs');
const path=require('node:path');
const [name,email,password]=process.argv.slice(2);
if(!name||!email||!password||password.length<12){console.error('Usage: node server/provision-admin.js "Name" email password-at-least-12-chars');process.exit(1)}
bcrypt.hash(password,12).then(async hash=>{
  try{
    if(process.env.DATABASE_URL){const {Pool}=require('pg');const pool=new Pool({connectionString:process.env.DATABASE_URL,max:1});await pool.query('INSERT INTO users(name,email,password_hash,role) VALUES($1,$2,$3,$4)',[name,email.toLowerCase(),hash,'admin']);await pool.end()}
    else{const sqlite3=require('sqlite3').verbose();const db=new sqlite3.Database(path.resolve(process.env.DATABASE_PATH||path.join(__dirname,'../data/lingua.db')));await new Promise((resolve,reject)=>db.run('INSERT INTO users(name,email,password_hash,role) VALUES(?,?,?,?)',[name,email.toLowerCase(),hash,'admin'],e=>e?reject(e):resolve()));db.close()}
    console.log(`Admin created: ${email}`)
  }catch(e){console.error(e.message);process.exitCode=1}
});
