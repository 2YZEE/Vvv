// Vercel's Express framework entrypoint. Local development uses server/index.js.
module.exports=require('./server/index');
